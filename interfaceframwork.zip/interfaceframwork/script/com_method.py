
import requests


class Test_login():
    def __init__(self):
        self.url = 'http://192.168.2.197:10050/api/v1/admin/login'
        self.info = {"id":"admin","passwd":"abcd.1234"}
    def test_login(self):
        r = requests.post(self.url,data=self.info).json()
        # print(r)
        a_token = r['token']
        # print(admin_token)

        return "Bearer"+" "+ a_token


admin_token = Test_login().test_login()
# print(admin_token)
