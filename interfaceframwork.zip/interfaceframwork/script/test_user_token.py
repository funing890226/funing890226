import requests
import json

url = "http://192.168.2.197:10070/api/v1/users/login"

payload = json.dumps({
   "username": "f12345678",
   "password": "abcd.1234",
   "channel": 2
})
headers = {
   'User-Agent': 'apifox/1.0.0 (https://www.apifox.cn)',
   'Content-Type': 'application/json'
}

response = requests.request("POST", url, headers=headers, data=payload)
print(response.json())
user_token = response.json()["data"]["token"]
print(user_token)
