import unittest
import requests
from script.com_method import admin_token

class Domnains(unittest.TestCase):
    def setUp(self):
        self.url = 'http://192.168.2.197:10050/api/v1/admin/login'
        self.headers = {"authorization":admin_token}
    def test_domains_get(self):
        r = requests.get(url=self.url, headers=self.headers)
        print(r.text)
        self.assertIn("200", str(r))
if __name__ == '__main__':
    unittest.main()



