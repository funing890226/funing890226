import requests
import unittest
import json
class testregister(unittest.TestCase):
    def setUp(self):
        self.url = "http://192.168.2.197:10050/api/v1/admin/login"
        self.userinfo = {"id": "admin",
                         "passwd": "abcd.1234"}
    def test_register(self):
        response = requests.post(self.url, data=self.userinfo).json()
        print(json.dumps(response,sort_keys=True, indent=4, separators=(',', ':')))

        self.assertIn("token", response)


if __name__ == '__main__':
    unittest.main()
