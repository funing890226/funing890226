import requests
import json

url = "http://192.168.2.197:10071/api/v1/users/dynamic/10000067"

payload = json.dumps({
  "operateType": "collection",
  "resourceType": 1,
  "operateState": 1
})
headers = {
  'authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzaW1wbGF5ZXJfdXNlciIsImV4cCI6MTY1OTAwNTg0MywianRpIjoiMyJ9.ZP8AzvTq-ycU1pHKh-u7f1TnY15SbXvl4H9nw4LSKy4',
  'Content-Type': 'application/json'
}

response = requests.request("PUT", url, headers=headers, data=payload)

print(response.text)
