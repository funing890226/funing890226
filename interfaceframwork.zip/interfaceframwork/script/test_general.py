import csv
import requests
import os
import unittest
from script.test_user_token import *




dir_testdatafile = os.path.abspath(os.path.join(os.getcwd(),".."))+"\\testdatafile"
dir_testreport = os.path.abspath(os.path.join(os.getcwd(),".."))+"\\testreport"
class Test_general(unittest.TestCase):
    def setUp(self):
        self.file = open(dir_testdatafile+"\\testfile.csv","r")
        self.table =csv.reader(self.file)
        self.headers ={'Content-Type': 'application/json',
                       "authorization": user_token
                       }
    def test_general(self):
        num = 0
        for row in self.table:
            num = num + 1
            if num > 1:
                data = row[6]
                # print(data)
                url = row[3]
                # print(url)
                mothod = row[4]
                # print(mothod)
                if mothod =="post":
                    response = requests.post(url, data=data,headers=self.headers).json()
                    self.assertIn(row[7], str(response))
                elif mothod == "get":
                    response =requests.get(url,params=data).json()
                    # print(response)
                    self.assertIn(row[7], str(response))
                elif mothod =="put":
                    response = requests.put(url, data=data)
                elif mothod =="delete":
                    pass
                else:
                    pass
    def tearDown(self):
        self.file.close()
if __name__ == '__main__':
    unittest.main()




