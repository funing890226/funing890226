
import reudom
import csv
import unittest
import requests
#登陆用例
class testcheck(unittest.TestCase):
    def setUp(self):
        self.url = 'http://192.168.2.197:10050/api/v1/admin/login'
        self.file = open("D:\\test\interfaceframwork\\testdatafile\checkuser.csv", "r")
        self.table =csv.reader(self.file)
    @reudom.skip("跳过")
    def test_check(self):
        checkinfo = {}
        num = 0
        for row in self.table:
            num = num + 1
            if num > 1:
                checkinfo["id"] = row[0]
                checkinfo["passwd"] = row[1]
                print(row[0])
                response = requests.post(self.url, data=checkinfo).json()
                self.assertIn(row[2], str(response))
    def tearDown(self):
        self.file.close()

if __name__ == '__main__':
    unittest.main()







