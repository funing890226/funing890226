
import reudom
import unittest
import csv
import operator
import time
from HTMLTestRunner import HTMLTestRunner
import os

now_time = time.strftime("%Y%m%d%H%M%S")
dir_report = os.path.abspath(os.path.join(os.getcwd(),".."))+"\\testreport"
dir_config = os.path.abspath(os.path.join(os.getcwd(),".."))+"\\config"
if __name__ == '__main__':
    #打开对应的配置文件，进行读取
    #以只读方式打卡
    with open(dir_config+"\\config1.csv", "r") as file:
        table=csv.reader(file)
        # line=len(open("D:\python\interfacefram\config\config1.csv").readlines())
        # print(line)
        dic={}
        listd=[]
        line=0
        for row in table:
            #print(row[0])
            if line>0:
            #把文件中读取的数据放入字典
                dic={}
                dic[row[1]]=row[0]
                dic["num"]=int(row[3])
            #把脚本运行状态加入字典数据
                dic["state"]=row[2]
                # print(dic)
            line=line+1
            if dic!={}:
                listd.append(dic)
        # print("n行数=",line)
        # print(listd)
        #排序
        dicn=sorted(listd,key=operator.itemgetter("num"))
        # print(dicn)
        for i in range(0,line-1):
            n=0
            for content in dicn[i].items():
                if n==0:
                    #print(content)
                    fname=content[0]
                    fdir=content[1]
                    # print("fname",fname,"    fdir",fdir)
                if n==2:
                    # print(content)
                    state=content[1]
                    # print("state",state)
                    if state=="Y":
                        #调用脚本程序进行执行
                        print("最终运行的程序",fname)
                        discover = unittest.defaultTestLoader.discover(fdir, pattern=fname)
                        # 定义一个运行对象
                        # runner = unittest.TextTestRunner()
                        # runner.run(discover)
                        # 输出测试报告
                        fp = open(dir_report+"\\"+now_time + "_result.html", "ab")
                        runner = HTMLTestRunner(stream=fp, title="test", description="浏览器")
                        runner.run(discover)
                        fp.close()
                        # 输出reudom测试报告
                        # reudom.main(path=fdir,title="test",description="测试",debug=False,save_last_run=False)
                n=n+1
reudom.main(path="D:\\test\interfaceframwork\script")

